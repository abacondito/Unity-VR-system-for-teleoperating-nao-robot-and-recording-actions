#! /bin/bash
cd /home/ubuntu
sudo apt-get update -y > /dev/null
echo "---> Update completato"
sudo apt-get upgrade -y > /dev/null
echo "---> Upgrade completato"

PUBLIC_DNS=$( curl http://169.254.169.254/latest/meta-data/public-hostname )
PEM_FILE=$( ls .ssh | grep ".pem" )

#setup kafka
sudo apt-get install -y openjdk-8-jdk > /dev/null
wget -q https://downloads.apache.org/kafka/2.5.0/kafka_2.12-2.5.0.tgz > /dev/null
sudo tar zxf kafka_2.12-2.5.0.tgz > /dev/null
mkdir kafka
sudo mv ./kafka_2.12-2.5.0/* /home/ubuntu/kafka
rm kafka_2.12-2.5.0.tgz
mkdir /home/ubuntu/zook
touch /home/ubuntu/zook/myid

#setup mongo
wget -qO - https://www.mongodb.org/static/pgp/server-4.4.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu bionic/mongodb-org/4.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.4.list
sudo apt-get update
sudo apt-get install -y mongodb-org

mkdir /home/ubuntu/config
touch /home/ubuntu/config/shard.conf
touch /home/ubuntu/config/repl1.conf
touch /home/ubuntu/config/repl2.conf

mkdir /home/ubuntu/db
mkdir /home/ubuntu/db/shardSvr
mkdir /home/ubuntu/db/repl1Svr
mkdir /home/ubuntu/db/repl2Svr

mkdir /home/ubuntu/logDb
touch /home/ubuntu/logDb/mongoShard.log
cp /home/ubuntu/logDb/mongoShard.log /home/ubuntu/logDb/repl1.log
cp /home/ubuntu/logDb/mongoShard.log /home/ubuntu/logDb/repl2.log

sudo cp /lib/systemd/system/mongod.service /lib/systemd/system/mongoShard.service
sudo cp /lib/systemd/system/mongod.service /lib/systemd/system/mongoRepl1.service
sudo cp /lib/systemd/system/mongod.service /lib/systemd/system/mongoRepl2.service



#sudo mongod --fork --config /home/ubuntu/config/mongo.conf --dbpath /home/ubuntu/db --logpath /home/ubuntu/log
#mongo
#use admin
#db.createUser({user: "superuser",pwd: "changeMeToAStrongPassword",roles: [ "root" ]})
#db.shutdownServer()
#exit
#sudo mongod --fork --dbpath /var/lib/mongodb --auth --logpath /home/ubuntu/log


# Aggiornamento file config della cartella .ssh
echo Host namenode >> /home/ubuntu/.ssh/config
echo HostName namenode >> /home/ubuntu/.ssh/config
echo User ubuntu >> /home/ubuntu/.ssh/config
echo IdentityFile /home/ubuntu/.ssh/$PEM_FILE >> /home/ubuntu/.ssh/config
echo >> /home/ubuntu/.ssh/config

echo Host datanode1 >> /home/ubuntu/.ssh/config
echo HostName namenode >> /home/ubuntu/.ssh/config
echo User ubuntu >> /home/ubuntu/.ssh/config
echo IdentityFile /home/ubuntu/.ssh/$PEM_FILE >> /home/ubuntu/.ssh/config
echo >> /home/ubuntu/.ssh/config

echo Host datanode2 >> /home/ubuntu/.ssh/config
echo HostName datanode1 >> /home/ubuntu/.ssh/config
echo User ubuntu >> /home/ubuntu/.ssh/config
echo IdentityFile /home/ubuntu/.ssh/$PEM_FILE >> /home/ubuntu/.ssh/config
echo >> /home/ubuntu/.ssh/config

echo Host datanode3 >> /home/ubuntu/.ssh/config
echo HostName datanode2 >> /home/ubuntu/.ssh/config
echo User ubuntu >> /home/ubuntu/.ssh/config
echo IdentityFile /home/ubuntu/.ssh/$PEM_FILE >> /home/ubuntu/.ssh/config
echo >> /home/ubuntu/.ssh/config

echo Host datanode4 >> /home/ubuntu/.ssh/config
echo HostName datanode3 >> /home/ubuntu/.ssh/config
echo User ubuntu >> /home/ubuntu/.ssh/config
echo IdentityFile /home/ubuntu/.ssh/$PEM_FILE >> /home/ubuntu/.ssh/config

# Creazione file template da modificare in seguito
echo | sudo tee -a /etc/hosts > /dev/null
echo "IP.MA.ST.ER namenode" | sudo tee -a /etc/hosts > /dev/null
echo "IP.MA.ST.ER datanode1" | sudo tee -a /etc/hosts > /dev/null
echo "IP.SL.AV.E1 datanode2" | sudo tee -a /etc/hosts > /dev/null
echo "IP.SL.AV.E2 datanode3" | sudo tee -a /etc/hosts > /dev/null
echo "IP.SL.AV.E3 datanode4" | sudo tee -a /etc/hosts > /dev/null

# Creazione chiavi ssh
ssh-keygen -qq -f /home/ubuntu/.ssh/id_rsa -t rsa -P ''
cat /home/ubuntu/.ssh/id_rsa.pub >> /home/ubuntu/.ssh/authorized_keys
#---> ssh datanode2 'cat >> /home/ubuntu/.ssh/authorized_keys'< /home/ubuntu/.ssh/id_rsa.pub
#---> ssh datanode3 'cat >> /home/ubuntu/.ssh/authorized_keys'< /home/ubuntu/.ssh/id_rsa.pub
#---> ssh datanode4 'cat >> /home/ubuntu/.ssh/authorized_keys'< /home/ubuntu/.ssh/id_rsa.pub


echo "---> Macchina pronta"
# ---continue---
